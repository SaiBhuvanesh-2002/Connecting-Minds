<!DOCTYPE html>
<html>
<head>
	<title>SIGN IN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
     
</head>
<body>
<br><br><br><br><br><br><br> 
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br>     
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br>     
 
     <form action="signup-check copy.php" method="post">
     	<h2>SIGN UP AS TUTOR</h2>
          <h4><a href="signup.php">Not Tutor?, Please Click On me</a></h4>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

       
          <label>Name</label>
          <?php if (isset($_GET['name'])) { ?>
               <input type="text" 
                      name="name" 
                      placeholder="Name"
                      value="<?php echo $_GET['name']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="name" 
                      placeholder="Name"><br>
          <?php }?>

          <label>User Name</label>
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="uname" 
                      placeholder="User Name"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="User Name"><br>
          <?php }?>
          <br>


          <label>Phone No:</label>
          <?php if (isset($_GET['pnum'])) { ?>
               <input type="text" 
                      name="pnum" 
                      placeholder="Phone Number"
                      value="<?php echo $_GET['pnum']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="pnum" 
                      placeholder="pnum"><br>
          <?php }?>



          <label>Mail ID:</label>
          <?php if (isset($_GET['mid'])) { ?>
               <input type="text" 
                      name="mid" 
                      placeholder="Email ID"
                      value="<?php echo $_GET['mid']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="mid" 
                      placeholder="Email ID"><br>
          <?php }?>


          <label for="birthday">Birthday:</label>
          <input type="date" id="birthday" name="bday">

          <br><br><br>
          
          <label>Subject Expertise:</label>
          <input type="text" id="sub" name="sub">
          <br><br><br>

          <label>Qualification:</label>
          <select name="qual" id="qual">
          <option value="Masters">Masters</option>
          <option value="M.tech">M.tech</option>
          <option value="B.tech">B.tech</option>
          <option value="B.com">B.com</option>
          </select>
          <br><br><br>

          <label>Experience:</label>
          <?php if (isset($_GET['exp'])) { ?>
               <input type="text" 
                      name="exp" 
                      placeholder="Experience"
                      value="<?php echo $_GET['exp']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="exp" 
                      placeholder="Experience"><br>
          <?php }?>

          <label>Class:</label>
          <select name="class" id="class">
          <option value="12+">12+</option>
          <option value="11-12">11-12</option>
          <option value="8-10">8-10</option>
          <option value="1-7">1-7</option>
          </select>
          <br><br><br>

          <label>Gender:</label>
          <?php if (isset($_GET['gen'])) { ?>
               <input type="text" 
                      name="gen" 
                      placeholder="Gender"
                      value="<?php echo $_GET['gen']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="gen" 
                      placeholder="Gender"><br>
          <?php }?>



         
          <label for="price">Price Range:</label>

          <select name="pay" id="pay">
          <option value="250-500">250-500</option>
          <option value="500-100">500-1000</option>
          <option value="1000-3000">1000-3000</option>
          <option value="3000+">3000+</option>
          </select>
          
          <br><br><br>

          <label>Language</label>
          <input type="text" 
               name="lang" 
               placeholder="Primary Language"><br>


     	<label>Password</label>
     	<input type = "password" id = "pswd"  value = "" name="password">   <br>

         
          <label>Captcha Verfication</label>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3Rd5qlCpmRp9sFbhfqY8-YsGGsKr6BbuUIw&usqp=CAU">
     	<input id="tk" type="cap" 
                 name="cap" 
                 placeholder="Enter the text"><br>
          <button  type="submit" onclick="verifyPassword()">Sign Up</button>
          <a href="index.php" class="ca">Already have an account?</a>
     </form>





<script>  
function verifyPassword() { 

  var myInput = document.getElementById("pswd");  
  //check empty password field  
  var lowerCaseLetters = /[a-z]/g;

  var s = "Passwords must meet all of the following criteria:\n";

  var x = 0;
  if(myInput.value.match(lowerCaseLetters)) {
    x += 1;
  }
  else{
  
  	
     s = s.concat("** Must contain Lower Case\n");

  
  
  }
    


  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {
    x += 1;
  } 
  else{
  	
    
    s = s.concat("** Must contain Upper Case\n");
  
  }
  

  // Validate numbers
  var numbers = /[0-9]/g;
  
  if(myInput.value.match(numbers)) {
    x+=1;
  }
  else{
  
  s = s.concat("** Must Contain Numbers\n");
  
  }

  // Validate length
  if(myInput.value.length >= 8) {
  	x+=1;
    
  }
  else{
  
  s = s.concat("** Minimum of 8 characters long\n");
  }
  
  if (x == 4){
  
  console.log("Success");

  
  }

  else{


     alert("Passwords must meet all of the following criteria:\n -> Minimum of 8 characters long \n -> Must contain all three of the following: \n -> Capital letter\n -> Lowercase letter  \n -> Number");
     alert(s);

  }
  

}  
</script> 
</body>
</html>










