<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/typed.js/1.1.4/typed.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .faq{
      margin-top:70px;
      margin-left: 10px;
    }

    .faq p{
      font-size:17px;
    }

    .faq p b{
      font-size: 20px;
      color: #116466;
      
 
    }
</style>
</head>

<div class="w3-top">
  <div class="w3-bar w3-card w3-black" style="opacity:">

    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-padding-large" style="text-decoration: none; color:white;">Connecting Minds</a>
    <a href="home_s.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a class="w3-bar-item w3-button w3-padding-large" href="pp.php">Requests</a> 
    <a class="w3-bar-item w3-button w3-padding-large" href="update.php">Update</a>
    <a class="w3-bar-item w3-button w3-padding-large" href="index-1.php">Logout</a>

  </div>
</div>

<div class="faq" >

  <p style="color:#3500D3;margin-left:650px;font-size:26px;font-weight:bolder;"> Help for Students</p>
  <p style="color:#3500D3;margin-left:450px;font-size:26px;font-weight:bolder;">Q&As to help you understand Connecting Minds better</p>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <p style=" margin-left:500px ">
        <lottie-player src="https://assets4.lottiefiles.com/packages/lf20_jCWSsE.json"  background="transparent"  speed="1"  style="width: 500px; height: 500px;"  loop  autoplay></lottie-player>
    </p>
<p> <b>1. How to find a tutor?</b> <br>
We at connecting minds had curated a list of top tutors with top notch experience in teaching,qualification and many more.</p>

<p> <b>2. How do I contact a tutor?</b><br>
Contacting a tutor with tutor finder is easy as it provides both mail id and phone number of the tutor which can be used for future
communications.
</p>
<p> <b>3. Steps to search a tutor?</b><br>
a.Select a subject and then apply fliters.
b.Click on Search .
c.Browse through the list of tutors who match your selection criteria.
</p>
 
 <p> <b>5. How many tutors should I contact?</b><br>
There may be a number of tutors listed for your search criteria. Please browse through each tutor's profile and contact those tutors who have more direct experience and expertise in the subject(s) you need help. It is a good idea to contact several tutors. This will greatly increase your chance of finding the right tutor.</p>

<p> <b>6. Expected time to accept the request by tutor?</b><br>
Most of the tutors are part time so we are working hard to on board full time and excepted time line will be 6-5 hrs .</p>

 