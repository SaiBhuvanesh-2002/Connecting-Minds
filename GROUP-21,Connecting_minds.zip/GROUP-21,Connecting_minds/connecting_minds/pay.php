<?php 
session_start();
include "db_conn.php";

$n = $_GET['name'];

$nn = $_GET['data'];
?>
<html>
<head>
	<title>HOME</title>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <link rel="stylesheet" type="text/css" href="syle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <li class="nav-item active">
        <a class="nav-link" href="home_s.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="pp.php">Requests</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="faq.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="update.php">Update</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index-1.php">Logout</a>
      </li>

      
    </ul>
    
  </div>
</nav>

<div class="container">
  <div class="row"> 
    <div class="col">
    <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y3qfynfr.json"  background="transparent"  speed="1"  style="width: 450px; height: 450px;"  loop  autoplay></lottie-player> 
    </div>
    <div class="col">
        <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_IG1Hp6.json"  background="transparent"  speed="1"  style="width: 450px; height: 450px;"  loop  autoplay></lottie-player>      
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>       
    </div>
</div>
<body style="background-color:#99ddff;">

<?php

if(isset($_POST['submit']))
{		

    $insert = mysqli_query($conn,"INSERT INTO request (tutor,student,status) VALUES ('$n','$nn','false')");

    $sql = "SELECT Pay_Range FROM users WHERE user_name='$nn' ";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $pay=$row['Pay_Range'];
	  $st="INSERT INTO payment (tutor,student,payment_status,amount) VALUES ('$n','$nn','true','$pay')";
    $insert1 = mysqli_query($conn,$st);
     
    if(!$insert)
    {
        echo mysqli_error();
    }
    else
    {
        echo '<script>alert("Request Sucessfully Sent")</script>';
      
    }
}

?>
<?php
    $sql= "SELECT * FROM teach WHERE user_name='$n' ";

    $result = mysqli_query($conn,$sql) or die("last error:{$conn->error}\n");
    $row=$result->fetch_array()
?>
<?php foreach ($result as $elements) : ?>    

<div class="row">
  <div class="col-sm-6" >
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Personal Information</h5>
        <p class="card-text"><b>Name:<?php echo $elements['name'];?></p>
            <p class="card-text">Teaching for :<?php echo $elements['Class'];?></p>                
            <p class="card-text">Qualification : <?php echo $elements['Qualification'];?></p>
            <p class="card-text">Experience in Teaching: <?php echo $elements['Experience'];?></p>
            <p class="card-text">Speaks and Teaches : <?php echo $elements['Language'];?></p>
         
      </div>
    </div>
  </div>
  <div class="col-sm-20">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Contact Information</h5>
        <p class="card-text">Email Adress: <?php echo $elements['Email'];?></p>
        <p class="card-text">Phone Number : <?php echo $elements['Ph_NO'];?></p>
        <form method="POST">
        <button type="submit" name="submit" value="Request" style="background: #ff912f;border: 2px solid #8a4100;padding: 10px;text-decoration: none;color: white;font-size: larger;border-radius: 10px;">Send Request</button>
        </form>        
      </div>
    </div>
  </div>
</div>

<?php endforeach; ?>
</body>
 
</html>

