<?php

$sname= "localhost:3307";
$unmae= "root";
$password = "root";
$db_name = "connecting_minds";

$conn = mysqli_connect($sname, $unmae, $password);

mysqli_select_db($conn,$db_name);

if (!$conn) {
	echo "Connection failed!";
}
