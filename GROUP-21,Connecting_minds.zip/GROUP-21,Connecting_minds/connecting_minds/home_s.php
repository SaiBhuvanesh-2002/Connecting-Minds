<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['user_name'])) {
    ?>
<!DOCTYPE html> 
<html>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Connecting Minds - Tutor Finder</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="pp.php">Requests</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="faq.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="update.php">Update</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index-1.php">Logout</a>
      </li>

       
      
    </ul>
    
  </div>
</nav>
  
</head>

<body >

  <section id="hero" style="background-image: url('assets/bg.png');">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
          <div>
          
    
    
            <h1 style="font-size: 50px;font-weight: 150;">WELCOME BACK! <?php echo $_SESSION['user_name']; ?></h1>
            <br><br>
            <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
            
            
            <lottie-player src="https://assets1.lottiefiles.com/packages/lf20_hzfmxrr7.json"  background="transparent"  speed="1"  style="width: 250px; height: 180px;"  loop  autoplay></lottie-player>
            
          </div>
        </div>
       

        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<lottie-player src="https://assets4.lottiefiles.com/private_files/lf30_LOw4AL.json"  background="transparent"  speed="1"  style="width: 400px; height: 500px;"  loop  autoplay></lottie-player>
        </div>
      </div>
    </div>

  </section><!-- End Hero -->
  <hr><hr>
  
  <main id="main" >
  
  
    <br><br><br>
    <div >
     <img src="assets/shap2.png" alt="">
     <div style="float: right;margin: top 600px;">
     <img src="assets/shap1.png" alt="">
    </div>
    <h1  style="margin-left: 550px; font-size: 50px;">Search For <span style="color:Red;">Tutor.</span></h1>
    <!-- ======= About Section ======= -->
    <section id="about" class="about" >
      <br><br>
      
      </div>
      
      
    <div class="card" style="width: 10rem;margin-left: 200px;margin-top:140px;float:left;box-shadow: 10px 10px 8px 10px #888888;">

        <div class="card-body" > 
        <form method="post" >
            <h2 class="card-title">Filters</h2>
            <h5 class="card-title">Qualification</h5>
              <p class="card-text">
              
              <div class="form-check form-switch">
              <input value='Masters' name='mas' class="form-check-input" type="checkbox" id="flexSwitchCheckDefult">
              <label class="form-check-label" for="flexSwitchCheckDefault">Masters</label>
              </div>
              <div class="form-check form-switch">
              <input value='B.tech' name='btech' class="form-check-input" type="checkbox" id="fleSwitchCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault">B.Tech</label>
              </div>
              <div class="form-check form-switch">
              <input value='M.tech' name='mtech' class="form-check-input" type="checkbox" id="flexSwitcCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault">M.Tech</label>
              </div>
              <div class="form-check form-switch">
              <input value='B.Com' name='bcom' class="form-check-input" type="checkbox" id="flewitchCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault">B.Com</label>
              </div>
              </p>
            
            
          </div>
          <div class="card-body" > 
            <h5 class="card-title">Experience</h5>
            <p class="card-text">
             
              <div class="form-check form-switch">
              <input value='2' name='f' class="form-check-input" type="checkbox" id="flexSwitchCheckDefult">
              <label class="form-check-label" for="flexSwitchCheckDefault"> <2 Years</label>
              </div>
              <div class="form-check form-switch">
              <input value='4' name='s' class="form-check-input" type="checkbox" id="fleSwitchCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault"> <4 Years</label>
              </div>
              <div class="form-check form-switch">
              <input value='6' name='e' class="form-check-input" type="checkbox" id="flexSwitcCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault"> <6 Years</label>
              </div>
              <div class="form-check form-switch">
              <input value='8' name='t' class="form-check-input" type="checkbox" id="flewitchCheckDefault">
              <label class="form-check-label" for="flexSwitchCheckDefault"> <8 Years</label>
              </div>
              </p>
            <input  class="btn btn-outline-success my-2 my-sm-0" name="submit" value='Apply' type="submit">
        </form>
        </div>
    </div>
    </div> 
    <div class="a" style="width: 25%; margin: 0px auto;margin-top:100px;">
          <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
          <lottie-player src="https://assets8.lottiefiles.com/packages/lf20_n2m0isqh.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"  loop  autoplay></lottie-player>
     </div> 
     
     <?php              
     $sql = "SELECT Pay_Range FROM users WHERE user_name='".$_SESSION['user_name']."' ";
	$result = mysqli_query($conn, $sql);
     $row = mysqli_fetch_assoc($result);
     $pay=$row['Pay_Range'];
     $sql1 = "SELECT Pay_Range FROM teach WHERE Pay_Range<= '$pay' ";
	$result1 = mysqli_query($conn, $sql1);
     $row2 = mysqli_fetch_assoc($result1);
     $pay1=$row2['Pay_Range'];
     $stack = array();
     while( $row = mysqli_fetch_array( $result1, MYSQLI_ASSOC ) ) {
          array_push( $stack, $row );
     }
     $theArray = json_encode( $stack );
       
     ?>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     
     <form class="example"  action="home_s.php" method="get"style="max-width:300px;margin-left: 690px; ">
          
          <input type="text" name="loc"  style="border-radius: 15px;"  placeholder="Enter the subject ">
          
          <button type="submit" name='submit'  style="border-radius: 10px;" class="btn btn-outline-success my-2 my-sm-0" style=""><i class="fa fa-search"></i></button>
     </form>

   
     
     
    
    </div>
    </div>
    
     <div class="container"  style = "margin-left: 600px;">

          
            <?php
            if(!empty($_GET['loc'])){
              $loc = $_GET['loc']?? '';
              
              $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' ";

              if(!empty($_POST['submit'])) {   
                $loc = $_GET['loc'];
                
                $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' ";
                $mas=($_POST['mas'])?? '';
                $mt=($_POST['mtech'])?? '';
                $bc=($_POST['bcom'])?? '';
                $bt=($_POST['btech'])?? '';
                $f=($_POST['f'])?? '';
                $s=($_POST['s'])?? '';
                $e=($_POST['e'])?? '';
                $t=($_POST['t'])?? '';
                
                if($f!='2' and $s!='4' and $e!='6' and $t!='8' and $mt!='M.tech' and $bc!='B.com' and $bt!='B.tech' and $mas!='Masters'){
                  
                  $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' ";
                }
                else{
                  
                  if($mt=='M.tech'){
                    
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Qualification='$mt' ";

                  }
                  if($bc=='B.com'){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Qualification='$bc' ";
                  }
                  if($bt=='B.tech' ){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Qualification='$bt' ";
                  }
                  if($mas=='Masters'){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Qualification='$mas' ";
                  }
                  if($f=='2'){
                    
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Experience<='$f' ";

                  }
                  if($e=='6'){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Experience<='$e' ";
                  }
                  if($s=='4' ){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Experience<='$s' ";
                  }
                  if($t=='8'){
                    $sql= "SELECT * FROM teach WHERE Pay_Range<='$pay' AND subject='$loc' AND Experience<='$t'   ";
                  }
                }
              
              $result = mysqli_query($conn,$sql) or die("last error:{$conn->error}\n");
              $row=$result->fetch_array();
              } 
              $result = mysqli_query($conn,$sql) or die("last error:{$conn->error}\n");
              $row=$result->fetch_array();
              ?>
              <div class="row">
              <?php foreach ($result as $elements) : ?>
                
                <div class="col-sm-4" style="width: 500px;height:700px;">
              <div class="card">
              <lottie-player src="https://assets6.lottiefiles.com/datafiles/i1uFIojbGt3KRN2/data.json"  background="transparent"  speed="1"  style="width: 200px; height: 200px;"  loop  autoplay></lottie-player>
                <div class="card-body">
                  <span style="color:black;" class="card-text"></span><br>
                  <span style="color:black;" class="card-text">Name: <?php echo $elements['name'];?></span><br><br>
                  <span style="color:black;" class="card-text">Teaching for: <?php echo $elements['Class'];?></span><br><br>
                  <span style="color:black;" class="card-text">Qualification: <?php echo $elements['Qualification'];?></span><br><br>
                  <span style="color:black;" class="card-text">Experience in Teaching: <?php echo $elements['Experience'];?></span><br><br>
                  <span  style="color:black;" class="card-text">Speaks and Teaches: <?php echo $elements['Language'];?></span><br><br>
                  <span style="color:black;">For Contact detials and to Send a Request Click Select</span><br><br>
                  
                  
                  <a href="money.php?data=<?=$elements['user_name']?>&name=<?=$_SESSION['user_name']?>"><button  onclick="read('<?php echo $elements['user_name'];?>')" id="myBtn" class="btn btn-primary center-block">Select</button>
                  
                  


                </div>
                
              </div>

              
            </div>
              
            
              <?php endforeach; ?>

              
              </div>
              
              
          </div>
      </div>
    <?php }?>
    

<br><br>
<br>
<br><br>
<style>
<style>
 
* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}
 
form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
</style>

<script>

function read(id) {

                console.log(id);


                var dots = document.getElementById(id);
                
                console.log(id);


                if (dots.style.border === "none") {
                	
                  dots.style.border = "thick solid #0000FF";
                
                } else {
                  dots.style.border = "none";
                  
                  
                }
              }



</script>

    

    

</body>

</html>



<?php 
}else{
     header("Location: index-1.php");
     exit();
}
 ?>