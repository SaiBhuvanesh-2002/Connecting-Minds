<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['user_name'])) {
    ?>
<!DOCTYPE html> 
<html>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Connecting Minds - Tutor Finder</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="pp.php">Home <span class="sr-only">(current)</span></a>
      </li>
      
    
      <li class="nav-item active">
        <a class="nav-link" href="home.php">Requests</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="faq_t.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Logout</a>
      </li>

    </ul>
    
  </div>
</nav>
  
</head>

<body >

<section id="hero" style="background-image: url('assets/bg-1.png');">

<div class="container">
  <div class="row">
    <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
      <div>
      


        <h1 style="font-size: 40px;">WELCOME BACK! <?php echo $_SESSION['user_name']; ?></h1>
        <br><br>
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        
        
        <lottie-player src="https://assets1.lottiefiles.com/packages/lf20_hzfmxrr7.json"  background="transparent"  speed="1"  style="width: 250px; height: 180px;"  loop  autoplay></lottie-player>
        
      </div>
    </div>
   

    <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<lottie-player src="https://assets7.lottiefiles.com/packages/lf20_q5qeoo3q.json"  background="transparent"  speed="1"  style="width: 600px; height: 500px;"  loop  autoplay></lottie-player>
    </div>
  </div>
</div>

</section> 
               <?php 
               $stu=$_SESSION['user_name'];
               $sql1 = "SELECT Pay_Range FROM teach WHERE user_name='$stu' ";
               $result1 = mysqli_query($conn, $sql1);
               $row2 = mysqli_fetch_assoc($result1);
               $sql2 = "SELECT COUNT(*) FROM request WHERE tutor='$stu' AND status='true'";
               $result3 = mysqli_query($conn, $sql2);
               $row3 = mysqli_fetch_assoc($result3);
               $sal=$row3['COUNT(*)'] * $row2['Pay_Range'] ;
               $cnt=$row3['COUNT(*)'];
               

    
               ?>
<br>
<br>
<div class="row">  
       <hr>  
      <div class="card border-primary mb-3" style="max-width: 50rem;">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player class="card-img-top" src="https://assets5.lottiefiles.com/packages/lf20_mrc7imzl.json"  background="transparent"  speed="1"  style="width: 500px; height: 400px;"  loop  autoplay></lottie-player>
        
        <div class="card-body text-primary">
          <h5 class="card-title">Revenue</h5>
          <p class="card-text">Total Earnings are <h4><?php echo $sal;?>  Rs</h4></p>
          
        </div>
      </div>
      <hr>
     
      <div class="card border-primary mb-3" style="max-width: 30rem;">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player class="card-img-top" src="https://assets10.lottiefiles.com/packages/lf20_yJ8wNO.json"  background="transparent"  speed="1"  style="width: 400px; height: 400px;"  loop  autoplay></lottie-player>
        <div class="card-body text-primary">
          <h5 class="card-title">Accepted Students</h5>
          <p class="card-text">Number of students <h4><?php echo $cnt;?> </h4></p>
          
        </div>
      </div>
      <hr>
      <div class="card border-primary mb-3" style="max-width: 30rem;">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player src="https://assets4.lottiefiles.com/packages/lf20_ur7sluxh.json"  background="transparent"  speed="1"  style="width: 400px; height: 400px;"  loop  autoplay></lottie-player>  
        <div class="card-body text-primary">
          <h5 class="card-title">Feedback</h5>
          <p class="card-text">You got an average of 4 stars</p>
          
        </div>
      </div>
      <hr>
</div>
</body>

</html>


<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>