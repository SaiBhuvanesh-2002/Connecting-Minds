<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['password']) && isset($_POST['name']) ) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}
	$uname = validate($_POST['uname']);
	$pass = validate($_POST['password']);
	$sub = validate($_POST['sub']);
	$name = validate($_POST['name']);
	$pnum = validate($_POST['pnum']);
	$mid = validate($_POST['mid']);
	$class = validate($_POST['class']);
	$qual = validate($_POST['qual']);
	$gen = validate($_POST['gen']);	
	$bday = validate($_POST['bday']);
	$pay = validate($_POST['pay']);
	$lang = validate($_POST['lang']);
	$exp = validate($_POST['exp']);
	$cap = validate($_POST['cap']);
	$role = "teacher";
	


	

	$user_data = 'uname='. $uname. '&name='. $name;


	if (empty($uname)) {
		header("Location: teacher.php?error=User Name is required&$user_data");
	    exit();
	}else if(empty($pass)){
        header("Location: teacher.php?error=Password is required&$user_data");
	    exit();
	}
	else if(($cap!="smwm")){
		header("Location: teacher.php?error=Wrong Captch&$user_data");
		exit();
	}
	


	else if(empty($name)){
        header("Location: teacher.php?error=Name is required&$user_data");
	    exit();
	}


	else{

		// hashing the password
		
	    $sql = "SELECT * FROM teach WHERE user_name='$uname' ";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: teacher.php?error=The username is taken try another&$user_data");
	        exit();
		}else {
			
				$sql2 = "INSERT INTO teach(user_name, password, name,Ph_NO,Email,Class,Qualification,Gender,DOB,Pay_Range,Language,Experience,role,subject) VALUES('$uname', '$pass', '$name','$pnum','$mid','$class','$qual','$gen','$bday','$pay','$lang','$exp','$role','$sub')";
				$result2 = mysqli_query($conn, $sql2);																									
				if ($result2) {
					header("Location: login.php?success=Your account has been created successfully");
					exit();
				}else {
					
						 
						header("Location: teacher.php?error=error&$user_data");
						exit();
           }


			}
			
		}
	
	
	}else{
	header("Location: teacher.php");
	exit();
}
?>