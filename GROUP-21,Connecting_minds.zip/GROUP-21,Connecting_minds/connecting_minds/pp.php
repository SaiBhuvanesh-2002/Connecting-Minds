<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['user_name'])) {
    ?>
<!DOCTYPE html> 
<html>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Connecting Minds - Tutor Finder</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <li class="nav-item active">
        <a class="nav-link" href="home_s.php">Home <span class="sr-only">(current)</span></a>
      </li>
 
      <li class="nav-item active">
        <a class="nav-link" href="faq.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="update.php">Update</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index-1.php">Logout</a>
      </li>

      
    </ul>
    
  </div>
</nav>
  
</head>

<body >

<section id="hero" style="background-image: url('bg-1.png');">

<div class="container">
  <div class="row">
    <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
      <div>
      


        <h1 style="font-size: 40px;">WELCOME BACK! <?php echo $_SESSION['user_name']; ?></h1>
        <br><br>
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        
        
        <lottie-player src="https://assets1.lottiefiles.com/packages/lf20_hzfmxrr7.json"  background="transparent"  speed="1"  style="width: 250px; height: 180px;"  loop  autoplay></lottie-player>
        
      </div>
    </div>
   

    <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<lottie-player src="https://assets7.lottiefiles.com/packages/lf20_q5qeoo3q.json"  background="transparent"  speed="1"  style="width: 600px; height: 500px;"  loop  autoplay></lottie-player>
    </div>
  </div>
</div>

</section><!-- End Hero --><!-- End Hero -->
<div  style="background-color:powderblue;">
   
  <main id="main"  style="background-color:powderblue;">
    <br><br><br>
    <h1 style="margin-left: 400px; font-size: 70px;">Find The Requests Accepted</h1>
    <!-- ======= About Section ======= -->
    <section id="about" class="about" >
      <br><br>
    <div class="a" style="width: 25%; margin: 0px auto;margin-top:100px;">
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <lottie-player src="https://assets5.lottiefiles.com/packages/lf20_bm3rmlqh.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"  loop  autoplay></lottie-player>
    </div>
  <div class="container"  >
      <div class="card-deck"  style="background-color:powderblue;">
        
           
     <?php
            $rr=$_SESSION['user_name'];
            $sql= "SELECT * FROM request WHERE student='$rr' AND status='true'";
            $result = mysqli_query($conn,$sql);
            $row=$result->fetch_array();
            if(!$row){
                echo '<h1 style="width: 120%; margin: 0px auto;" >No Requets Found</h1>';
                echo '<lottie-player  src="https://assets4.lottiefiles.com/packages/lf20_MetBbE.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"  loop  autoplay></lottie-player>';
            }
            ?>
            <div class="row">
            <?php foreach ($result as $elements) : ?>
            
              
               <?php $stu=$elements['tutor']; 
                
               ?>
               
               <?php 
               $sql1 = "SELECT * FROM teach WHERE user_name='$stu' ";
               $result1 = mysqli_query($conn, $sql1);
               
                $row2 = mysqli_fetch_assoc($result1);
               
               ?>
                
                <div class="col-sm-4" style="width: 500px;height:800px;padding-top:20px;">
                
              <div class="card">
              <lottie-player src="https://assets6.lottiefiles.com/datafiles/i1uFIojbGt3KRN2/data.json"  background="transparent"  speed="1"  style="width: 200px; height: 200px;"  loop  autoplay></lottie-player>
              
                <div class="card-body">
                  <span style="color:black;" class="card-text"></span><br>
                  <span style="color:black;" class="card-text">Name:<?php echo $row2['name'];?></span><br><br>
                  <span style="color:black;" class="card-text">Teaching for :<?php echo $row2['Pay_Range'];?></span><br><br>
                  <span style="color:black;" class="card-text">Qualification : <?php echo $row2['Qualification'];?></span><br><br>
                  <span style="color:black;" class="card-text">Experience in Teaching: <?php echo $row2['Ph_NO'];?></span><br><br>
                  <span  style="color:black;" class="card-text">Speaks and Teaches : <?php echo $row2['Email'];?></span><br><br>
                  <span style="color:black;">For Contact detials and to Send a Request Click Select</span><br><br>
                  <a class="btn btn-primary" style="background: #ff912f;border: 2px solid #8a4100;padding: 10px;text-decoration: none;color: white;font-size: larger;border-radius: 10px;" data-toggle="collapse" href="#<?php echo $stu?>" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Feedback</a>

                  <div class="collapse multi-collapse" id="<?php echo $stu?>">
                        <div >
                           <br>
                           <br>
                        <form   action="pp.php?data=<?=$stu?>" method="post" >
          
                              <input type="text" name="loc"   style="border-radius: 10px;"placeholder="Enter the Rating scale 1-5 ">
                              
                              <button type="submit"  style="background: #997300;border: 1px solid #cc9900;padding: 5px;text-decoration: none;color: white ;border-radius: 10px;" class="btn btn-primary" name='submit'   style="">Submit</button>
                        </form>
                        </div>
                  </div>
                </div>
              </div>
            </div>
              
              <br>
              <br>
              <?php endforeach; ?>
              </div>
              
    <?php }?>
</div>  

<?php

if(!empty($_POST['loc'])){
  $pp=$_POST['loc']?? '';
  $s=$_GET['data']?? '';
  $sql="UPDATE request SET feedback = '$pp' WHERE tutor='$s' AND student='$rr';";
  echo "<h1>'$sql'</h1>";
      $inser=mysqli_query($conn,$sql);   
      echo "<h1>'$inser'</h1>";  
      echo mysqli_error($conn);
      if(!$inser)
      {
          echo "<h1>dd</h1>";
      }
      echo '<script>alert("Thanks For The Feedback") </script>';
 
}
?>

<style>
 

* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
</style>

<script>

function read(id) {

                console.log(id);


                var dots = document.getElementById(id);
                
                console.log(id);


                if (dots.style.border === "none") {
                	
                  dots.style.border = "thick solid #0000FF";
                
                } else {
                  dots.style.border = "none";
                  
                  
                }
              }



</script>

    

    

</body>

</html>


 