<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/typed.js/1.1.4/typed.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .faq{
      margin-top:70px;
      margin-left: 10px;
    }

    .faq p{
      font-size:17px;
    }

    .faq p b{
      font-size: 20px;
      color: #116466;
    }
</style>
</head>

<div class="w3-top">
  <div class="w3-bar w3-card w3-black" style="opacity:">

    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-padding-large" style="text-decoration: none; color:white;">Connecting Minds</a>
    <a href="teach.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a class="w3-bar-item w3-button w3-padding-large" href="home.php">Requests</a>
    
    <a class="w3-bar-item w3-button w3-padding-large" href="index-1.php">Logout</a>

  </div>
</div>

<div class="faq">

  <p style="color:#3500D3;margin-left:650px;font-size:26px;font-weight:bolder;"> Help for Tutors</p>
  <p style="color:#3500D3;margin-left:450px;font-size:26px;font-weight:bolder;">Q&As to help you understand Connecting Minds better</p>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <p style=" margin-left:500px ">
        <lottie-player src="https://assets4.lottiefiles.com/packages/lf20_jCWSsE.json"  background="transparent"  speed="1"  style="width: 500px; height: 500px;"  loop  autoplay></lottie-player>
    </p>
    <p>  
 
 
<p> <b>1. Is there any registration fee to work as tutor?</b></p>
Initially you can avail all the services in basic plan ,in futre we are going to keep plans which may cost and give additional benefits.<p>
 
<p> <b>2. Where can I see my earnings and feedback etc.?</b></p>
After sucessfull login you can see all the inforamtion in home page which will dynamiicaly change accroding to your performace .
<p> <b>7. How much can I earn from tutoring?</b></p>
There is no limit you can work hard to make the most of earnings.
<p> <b>8. What happens after I register?</b></p>
Your information will be stored safely in our database and students can find your profile and they can select.
 
<p> <b>9. Where to find the students requests?</b></p>
After sucessfull login you can see at the top named "requests" click and see the requests you recived.
</div>