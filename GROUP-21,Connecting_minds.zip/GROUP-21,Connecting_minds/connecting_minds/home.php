<?php 
session_start();
include "db_conn.php";
if (isset($_SESSION['user_name'])) {
    ?>
<!DOCTYPE html> 
<html>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Connecting Minds - Tutor Finder</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="teach.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="home.php">Requests</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="faq_t.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index-1.php">Logout</a>
      </li>

      
    </ul>
    
  </div>
</nav>
  
</head>


<section id="hero" style="background-image: url('assets/bg.png');">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
          <div>
          
    
    
            <h1 style="font-size: 50px;font-weight: 150;">WELCOME BACK! <?php echo $_SESSION['user_name']; ?></h1>
            <br><br>
            <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
            
            
            <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
            <lottie-player src="https://assets2.lottiefiles.com/private_files/lf30_glx8cv4o.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"  loop  autoplay></lottie-player>            
          </div>
        </div>
       

        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player src="https://assets1.lottiefiles.com/private_files/lf30_j59Vq2.json"  background="transparent"  speed="1"  style="width: 750px; height: 750px;"  loop  autoplay></lottie-player>        </div>
      </div>
    </div>

</section><!-- End Hero -->
<body style="background-color:#99ddff;">
    <div class="a" style="width: 30%; margin: 0px auto;">
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
        <lottie-player src="https://assets7.lottiefiles.com/packages/lf20_eTM2vQ.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"  loop  autoplay></lottie-player>
    </div>
         
     <div class="container" style = "padding-left: 40px; ">
      
        <div class="row">
            <?php
            $rr=$_SESSION['user_name'];
            $sql= "SELECT * FROM request WHERE tutor='$rr' AND status='false'";
            $result = mysqli_query($conn,$sql);
            $row=$result->fetch_array();
            if(!$row){
                echo '<h1 style=" margin-left: 350px;" >No Requets Found</h1>';
                
                echo '<lottie-player  src="https://assets4.lottiefiles.com/packages/lf20_MetBbE.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;margin-left: -350px;margin-top: 100px;"  loop  autoplay></lottie-player>';
            }
            ?>
            <?php foreach ($result as $elements) : ?>
               
               <?php $stu=$elements['student']; 
                
               ?>
               
               <?php 
               $sql1 = "SELECT * FROM users WHERE user_name='$stu' ";
               $result1 = mysqli_query($conn, $sql1);
               
                $row2 = mysqli_fetch_assoc($result1);
               
               ?>
           <div class="col-sm-4" style="width: 500px;height:700px;">
              <div class="card">
              <lottie-player src="https://assets6.lottiefiles.com/datafiles/i1uFIojbGt3KRN2/data.json"  background="transparent"  speed="1"  style="width: 200px; height: 200px;"  loop  autoplay></lottie-player>
                <div class="card-body">
                  <span style="color:black;" class="card-text"></span><br>
                  <span style="color:black;" class="card-text">Name:<?php echo $row2['name'];?></span><br><br>
                  <span style="color:black;" class="card-text">Pay Range Offered :<?php echo $row2['Pay_Range'];?></span><br><br>
                  <span style="color:black;" class="card-text">Email Adress : <?php echo $row2['Email'];?></span><br><br>
                  <span style="color:black;" class="card-text">Contact Number: <?php echo $row2['Ph_No'];?></span><br><br>
                  <span style="color:black;">For Contact detials and to Send a Request Click Select</span><br><br>
                  
                  
                  <a href="home.php?data=<?=$row2['user_name']?>"><button   id="myBtn" style="background: #ff912f;border: 2px solid #8a4100;padding: 10px;text-decoration: none;color: white;font-size: larger;border-radius: 10px;">Accept</button>
                </div>
              </div>
            </div>
              <br>

            <?php endforeach; ?>
            
          </div>
    </div>

   

<br><br>
<br>
<br><br>

  

<?php
$pp=$_GET['data']?? '';
		

$insert=mysqli_query($conn,"UPDATE request SET status = 'true' WHERE student='$pp' ");     
if(!$insert)
{
    echo mysqli_error();
}
else{
    if ($pp!=""){
        echo '<script>alert("Request Accepted") </script>';
       

    }
   
} 
?>
<style>
.content {
    width: 30%; 
    margin: 0px auto;
}
</style>
</body>
</html>




<?php 
}else{
     header("Location: index-1.php");
     exit();
}
 ?>
