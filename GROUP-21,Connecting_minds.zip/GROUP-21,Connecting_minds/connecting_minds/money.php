<?php 
session_start();
include "db_conn.php";

$n = $_GET['name'];
$nn = $_GET['data'];
?>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="styl.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <li class="nav-item active">
        <a class="nav-link" href="home_s.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="pp.php">Requests</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="faq.php">Support</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="update.php">Update</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index-1.php">Logout</a>
      </li>
    </ul>
    
  </div>
</nav>

<body style="background-color:#99ddff;">

            <?php
            $sql= "SELECT * FROM users WHERE user_name='$n'";
            $result = mysqli_query($conn, $sql);
            $row= mysqli_fetch_assoc($result);
            ?>

<div class="container">
  <div class="row">
  
    <div class="col-sm-8">
      <div id='' >
      <br>
      <br>
      <br>
      <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
      <lottie-player src="https://assets7.lottiefiles.com/packages/lf20_yzoqyyqf.json"  background="transparent"  speed="1"  style="width: 450px; height: 400px;"  loop  autoplay></lottie-player>
      </div>
    </div>
    
    <div class="col-sm-4">
           <br>
           <br>
      <h3 class="text-left" style="margin-left: -80px;">Billing Information of User</h3>
      <br>
      <h4 class="text-left">Name : <?php echo $row['name'];?></h4>
      <br>
      <h4 class="text-left">Contact : <?php echo $row['Ph_No'];?></h4>  
      <br>              
      <h4 class="text-left">Email : <?php echo $row['Email'];?></h4>

      <br>
      <h4 class="text-left">Total Payment: 200 Rs</h4>
      <br>
      <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Payment Information</a>

      <div class="collapse multi-collapse" id="multiCollapseExample1">
            <div >
              <br>
              <br>
              <h4 class="text-left">Gateway Charges : 40 Rs</h4>                
              <h4 class="text-left">Service Charges : 60 Rs</h4>
            </div>
      </div>
      <br>
      <br>
      <label for="lname"><h4>UPI ID:</h4></label>
      <br>
      <input type="text" id="lname" name="lname"><br><br>
      <a  href="pay.php?data=<?=$n?>&name=<?=$nn?>" id="__UPI_BUTTON__" style="background: #ff912f;border: 2px solid #8a4100;padding: 10px;text-decoration: none;color: white;font-size: larger;border-radius: 10px;">Pay using UPI</a>

      </div>
          </div>
    </div>

<style>
div.a{
  display:inline-block;
  text-align: left;
}
 
</style>
</body>
</html>
