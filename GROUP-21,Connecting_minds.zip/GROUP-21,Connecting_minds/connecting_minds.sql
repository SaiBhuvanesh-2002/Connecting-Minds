-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3305
-- Generation Time: Apr 30, 2021 at 07:45 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `connecting_minds`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `tutor` varchar(255) NOT NULL,
  `student` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`tutor`, `student`, `payment_status`, `amount`) VALUES
('gopi', 'pavan', 'true', '400'),
('krish', 'virat', 'true', '500');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `tutor` varchar(255) NOT NULL,
  `student` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`tutor`, `student`, `status`, `feedback`) VALUES
('gopi', 'raj', 'true', '4'),
('gopi', 'raj', 'true', '4'),
('gopi', 'raj', 'true', '4'),
('ravi', 'raj', 'true', '4'),
('ravi', 'raj', 'true', '4'),
('krish', 'pavan', 'true', '4'),
('ravi', 'raj', 'true', '4'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('ravi', 'pavan', 'true', '2'),
('gopi', 'pavan', 'true', '1'),
('gopi', 'pavan', 'true', '1'),
('', '', 'true', '4'),
('ravi', 'pavan', 'true', '2'),
('gopi', 'pavan', 'true', '4'),
('gopi', 'pavan', 'true', '4'),
('gopi', 'pavan', 'true', '4'),
('gopi', 'puja', 'true', '4'),
('gopi', 'pavan', 'false', ''),
('gopi', 'pavan', 'false', ''),
('krish', 'virat', 'false', '');

-- --------------------------------------------------------

--
-- Table structure for table `teach`
--

CREATE TABLE `teach` (
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Ph_NO` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Class` varchar(255) NOT NULL,
  `Qualification` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `DOB` date NOT NULL,
  `Pay_Range` int(255) NOT NULL,
  `Language` varchar(255) NOT NULL,
  `Experience` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teach`
--

INSERT INTO `teach` (`user_name`, `password`, `name`, `Ph_NO`, `Email`, `Class`, `Qualification`, `Gender`, `DOB`, `Pay_Range`, `Language`, `Experience`, `role`, `subject`) VALUES
('ravi', 'ravi', 'Ravi Kumar', '99742126625', 'ravi@gmail.com', '11-12', 'M.tech', 'm', '2021-04-12', 500, 'english', '5', 'tutor', 'math'),
('teja', 'tej', 'Teja', '8746146156', 'tej@gmail.com', '12+', 'M.tech', 'f', '2021-04-12', 1000, 'english', '4', 'tutor', 'science'),
('gopi', 'gopi', 'Gopal', '87684152614', 'gopi@gmail.com', '12+', 'B.tech', 'm', '2021-04-12', 250, 'Telugu', '6', 'tutor', 'math'),
('krish', '123', 'krish', '95641584541', 'krish@gmail.com', '12+', 'M.tech', 'm', '2021-04-13', 500, 'english', '2', 'tutor', 'math'),
('test_tutor', 'test', 'test_tutor', '652615268', 'test_tutor@gmail.com', '12', 'M.tech', 'm', '2020-06-01', 250, 'english', '4', 'tutor', 'math');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Ph_No` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Class` varchar(255) NOT NULL,
  `Institution` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `DOB` varchar(255) NOT NULL,
  `Pay_Range` int(255) NOT NULL,
  `Language` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_name`, `password`, `name`, `Ph_No`, `Email`, `Class`, `Institution`, `Gender`, `DOB`, `Pay_Range`, `Language`, `role`) VALUES
('ela', 'ula', 'Ela', '', '', '', '', '', '', 0, '', ''),
('karthik', 'karthik', 'karthik', '', '', '', '', '', '', 0, '', ''),
('mini', 'pass', 'KV', '6516551651', 'kvmailcom', 'eng 2nd yr', 'srm', 'male', '2021-03-18', 0, 'eng', ''),
('pp', 'pp', 'pp', 'pp', 'pp', 'pp', '', 'pp', '2021-03-08', 0, '', ''),
('m', 'm', 'm', 'm', 'm', 'm', '', 'm', '2021-03-17', 0, '', ''),
('p', 'p', 'Tankala Yuvaraj', '+918074010350', 'uv@gmail', '1', 'srm', '11', '2021-03-25', 250, '1', 'student'),
('testt', 'Puji_kumari@175', 'Tankala Yuvaraj', '+918074010350', '1', 's', 'a', '11', '2021-03-25', 250, '', 'student'),
('raj', 'uv', 'Tankala Yuvaraj', '+918074010350', 'uv@gmail', '9', 'srm', 'm', '2021-04-11', 1000, 'english', 'student'),
('pavan', 'Puji_kumari@175', 'Pavan', '745412584565', 'pavan@gmail.com', '12', 'SRM AP', 'm', '2021-04-13', 400, 'english', 'student'),
('puja', 'Puji_kumari@175', 'Puja', '9959478525', 'puja@gmail.com', '12', 'SRM', 'M', '06-02-2002', 250, 'english', 'student'),
('virat', 'Yuvaraj@06', 'Virat', '87454123', 'virat@gmail.com', '12', 'SRM', 'm', '01-11-1999', 500, 'Telugu', 'student'),
('test_student', 'test', 'testing', '807410350', 'test@gmail.com', '12', 'SRM', 'm', '06-02-2002', 1000, 'english', 'student');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
